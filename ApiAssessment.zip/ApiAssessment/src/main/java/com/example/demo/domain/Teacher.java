package com.example.demo.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Teacher implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int tId;	
	private String firstName;
	private String lastName;
	private Classes classes;
	
	public Teacher() {
		
	}
	
	public Teacher(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public Teacher(String firstName, String lastName, Classes classes) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.classes = classes;
	}

	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int gettId() {
		return tId;
	}

	public void settId(int tId) {
		this.tId = tId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@ManyToOne
    @JoinColumn(name="classId")
	public Classes getClasses() {
		return classes;
	}
	
	public void setClasses(Classes classes) {
		this.classes = classes;
	}

}
