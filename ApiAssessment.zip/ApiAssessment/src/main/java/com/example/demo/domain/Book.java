package com.example.demo.domain;

import java.io.Serializable;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Book implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Classes classes;
	private int bookId;
	private String bookName;
	
	public Book() {
		
	}
	
	public Book(String BookName) {
		this.bookName = BookName;
	}
	
	public Book (String bookName, Classes classes)
	{
		this.bookName = bookName;
		this.classes = classes;
	}
		
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getBookId() {
		return bookId;
	}
	
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	@ManyToOne
    @JoinColumn(name="classId")
	public Classes getClasses() {
		return classes;
	}
	
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	
	
}
