package com.example.demo.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Classes implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int classId;
	private String className;
	private Set<Book> books;
	private Set<Student> students;
	private Set<Teacher> teacher;
	
	public Classes(){
		
	}
	
	public Classes(String className) {
		this.className = className;
	}
	
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	
	@OneToMany(mappedBy = "classes", cascade = CascadeType.ALL)
	public Set<Book> getBooks(){
		return books;
	}
	public void setBooks(Set<Book> books) {
		this.books = books;
	}
	
	@OneToMany(mappedBy = "classes", cascade = CascadeType.ALL)
	public Set<Student> getStudent(){
		return students;
	}
	public void setStudent(Set<Student> students) {
		this.students = students;
	}
	
	@OneToMany(mappedBy = "classes", cascade = CascadeType.ALL)
	public Set<Teacher> getTeacher(){
		return teacher;
	}
	public void setTeacher(Set<Teacher> teacher) {
		this.teacher = teacher;
	}
	
}
