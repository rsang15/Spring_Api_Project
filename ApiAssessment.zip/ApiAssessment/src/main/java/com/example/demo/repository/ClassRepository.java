package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.domain.Classes;

public interface ClassRepository extends JpaRepository<Classes, Integer>{

}
