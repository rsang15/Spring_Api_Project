package com.example.demo;

import java.util.ArrayList;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.domain.Book;
import com.example.demo.domain.Classes;
import com.example.demo.domain.Student;
import com.example.demo.domain.Teacher;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.ClassRepository;
import com.example.demo.repository.StudentRepository;
import com.example.demo.repository.TeacherRepository;

@Controller
public class HibernateController {
	
	@Autowired private ClassRepository classRepo;
	@Autowired private BookRepository bookRepo;
	@Autowired private StudentRepository sRepo;
	@Autowired private TeacherRepository tRepo;
	
	@RequestMapping(value="Classes", method=RequestMethod.GET)
	public @ResponseBody List<String> getClassName()
	{
		List<Classes> classObjects = classRepo.findAll();
		List<String> classList = new ArrayList<>();
		for (Classes classes : classObjects) {
			String getclassList = String.format("%d, %s", classes.getClassId(), classes.getClassName());
			classList.add(getclassList);
		}
		return classList;
		
	}
	@RequestMapping(value="Book", method=RequestMethod.GET)
	public @ResponseBody List<String> getbooks()
	{
		List<Book> bookObjects = bookRepo.findAll();
		List<String> bookList = new ArrayList<>();
		for (Book book : bookObjects) {
			String bookClass = String.format("%d, %s", book.getBookId(), book.getBookName());
			bookList.add(bookClass);
		}
		return bookList;

	}
	@RequestMapping(value="Teacher", method=RequestMethod.GET)
	public @ResponseBody List<String> getTeachers()
	{
		List<Teacher> teacherObjects = tRepo.findAll();
		List<String> teacherList = new ArrayList<>();
		for (Teacher teacher : teacherObjects) {
			String teacherClass = String.format("%d %s,%s", teacher.gettId(), teacher.getFirstName(), teacher.getLastName());
			teacherList.add(teacherClass);
		}
		return teacherList;
		
	}
	@RequestMapping(value="Student", method=RequestMethod.GET)
	public @ResponseBody List<String> getStudents()
	{
		List<Student> studentObjects = sRepo.findAll();
		List<String> studentList = new ArrayList<>();
		for (Student student : studentObjects) {
			String studentClass = String.format("%d %s,%s", student.getsId(), student.getFirstName(), student.getLastName());
			studentList.add(studentClass);
		}
		return studentList;
	}
	
	@RequestMapping(value="Classes", method=RequestMethod.POST)
	public @ResponseBody Classes insertClass(@RequestParam String className)
	{
		Classes class1 = new Classes();
		class1.setClassName(className);
		
		return classRepo.save(class1);
	}
	
	@RequestMapping(value="Book", method=RequestMethod.POST)
	public @ResponseBody Book insertBook(@RequestParam String bookName, @RequestParam int classId )
	{
		Book b = new Book();
		Classes classes = classRepo.getOne(classId);
		
		b.setBookName(bookName);
		b.setClasses(classes);
		Set<Book> bookList = classes.getBooks();
		bookList.add(b);
		classes.setBooks(bookList);
		
		classRepo.save(classes);
		
		return b;
	}
	
	@RequestMapping(value="Student", method=RequestMethod.POST)
	public @ResponseBody Student insertStudent(@RequestParam String firstName, @RequestParam String lastName, @RequestParam int classId)
	{
		Student s = new Student();
		Classes classes = classRepo.getOne(classId);
		s.setFirstName(firstName);
		s.setLastName(lastName);
		s.setClasses(classes);
		Set<Student> StudentList = classes.getStudent();
		StudentList.add(s);
		classes.setStudent(StudentList);
		
		classRepo.save(classes);
		
		return s;
	}
	
	@RequestMapping(value="Teacher", method=RequestMethod.POST)
	public @ResponseBody Teacher insertTeacher(@RequestParam String firstName, @RequestParam String lastName, @RequestParam int classId)
	{
		Teacher t = new Teacher();
		Classes classes = classRepo.getOne(classId);
		t.setFirstName(firstName);
		t.setLastName(lastName);
		t.setClasses(classes);
		Set<Teacher> teacherList = classes.getTeacher();
		teacherList.add(t);
		classes.setTeacher(teacherList);
		
		classRepo.save(classes);
		
		return t;
	}
	
	@RequestMapping(value="Classes/{classId}", method=RequestMethod.DELETE)
	public @ResponseBody void deleteClass(@PathVariable int classId)
	{
		classRepo.deleteById(classId);
	}
	
	@RequestMapping(value="Book/{bookId}", method=RequestMethod.DELETE)
	public @ResponseBody void deleteBook(@PathVariable int bookId)
	{
		classRepo.deleteById(bookId);
	}
	
	@RequestMapping(value="Teacher/{tId}", method=RequestMethod.DELETE)
	public @ResponseBody void deleteTeacher(@PathVariable int tId)
	{
		classRepo.deleteById(tId);
	}
	
	@RequestMapping(value="Student/{sId}", method=RequestMethod.DELETE)
	public @ResponseBody void deleteStudent(@PathVariable int sId)
	{
		classRepo.deleteById(sId);
	}
	
	@RequestMapping(value="Classes/{classId}", method=RequestMethod.PUT)
	public @ResponseBody Classes updateClass(@PathVariable int classId, @RequestParam String className)
	{
		Classes class1 = classRepo.getOne(classId);
		class1.setClassName(className);
		
		Classes c = classRepo.save(class1);
		return c;
	}
	
	@RequestMapping(value="Book/{bookId}", method=RequestMethod.PUT)
	public @ResponseBody Book updateBook(@PathVariable int bookId, @RequestParam String bookName)
	{
		Book b1 = bookRepo.getOne(bookId);
		b1.setBookName(bookName);
		
		Book b = bookRepo.save(b1);
		return b;
	}
	
	@RequestMapping(value="Teacher/{tId}", method=RequestMethod.PUT)
	public @ResponseBody Teacher updateTeacher(@PathVariable int tId, @RequestParam String firstName, @RequestParam String lastName)
	{
		Teacher t = tRepo.getOne(tId);
		t.setFirstName(firstName);
		t.setLastName(lastName);
		
		Teacher t1 = tRepo.save(t);
		return t1;
	}
	
	@RequestMapping(value="Student/{sId}", method=RequestMethod.PUT)
	public @ResponseBody Student updateStudent(@PathVariable int sId, @RequestParam String firstName, @RequestParam String lastName)
	{
		Student s = sRepo.getOne(sId);
		s.setFirstName(firstName);
		s.setLastName(lastName);
		
		return sRepo.save(s);
	}
	
	@RequestMapping(value="BookClasses", method=RequestMethod.GET)
	public @ResponseBody List<String> fetchBookClasses()
	{
		List<Book> bookObjects = bookRepo.findAll();
		List<String> bookClassesList = new ArrayList<>();
		for (Book book : bookObjects) {
			String bookClass = String.format("%s(%s)", book.getBookName(),book.getClasses().getClassName());
			bookClassesList.add(bookClass);
		}
		return bookClassesList;
	 
	}
	
	@RequestMapping(value="StudentClasses", method=RequestMethod.GET)
	public @ResponseBody List<String> fetchStudentClasses()
	{
		List<Student> studentObjects = sRepo.findAll();
		List<String> studentClassesList = new ArrayList<>();
		for (Student student : studentObjects) {
			String studentClass = String.format("%s %s(%s)", student.getFirstName(), student.getLastName(), student.getClasses().getClassName());
			studentClassesList.add(studentClass);
		}
		return studentClassesList;
	 
	}
	
	@RequestMapping(value="TeacherClasses", method=RequestMethod.GET)
	public @ResponseBody List<String> fetchTeacherClasses()
	{
		List<Teacher> teacherObjects = tRepo.findAll();
		List<String> teacherClassesList = new ArrayList<>();
		for (Teacher teacher : teacherObjects) {
			String teacherClass = String.format("%s %s(%s)", teacher.getFirstName(), teacher.getLastName(), teacher.getClasses().getClassName());
			teacherClassesList.add(teacherClass);
		}
		return teacherClassesList;
	 
	}
	
	
}